Test images from:
https://github.com/JosePMarques/MP2RAGE-related-scripts

Relased under GPL-3 license, see License.txt
